# ricklib

This is a work in progress library for things like rendering mathematical images / making art and manipulating audio.

# Modules

Graphics
===

### graphcs2d
Make a frame and add circles / lines to it! Very primitive, but used in printing graphs in glib

### pngenerator
Creates png files from lists


Audio
===

### audio
lists <-> .wav files



Math
===

### glib
a graph library

### polynomial
a polynomial library