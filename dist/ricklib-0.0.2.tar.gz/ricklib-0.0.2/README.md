# ricklib

This is a work in progress library for things like rendering mathematical images / making art and manipulating audio.

# Modules

## graphics

### pngenerator

Creates png files from lists