# ricklib

This is a work in progress library for things like rendering mathematical images / making art and manipulating audio.

# Modules

## __graphical things__

### pngenerator
Creates png files from lists

## __audio things__

### audio
turn lists into .wav files
