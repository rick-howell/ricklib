from ricklib import pngenerator

pngenerator.test_gray()
pngenerator.test_rgb()